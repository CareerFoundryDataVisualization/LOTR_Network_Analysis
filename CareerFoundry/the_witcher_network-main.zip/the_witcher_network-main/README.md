# the_witcher_network
Source code for the Witcher network project tutorial on my Youtube channel.

![network pic 2](https://user-images.githubusercontent.com/22730220/174459596-56fe0394-f263-4090-8ee6-61d77b9a3363.jpeg)

## Tutorial: 

* Episode 1 - [Scraping character names from The Witcher Wiki](https://www.youtube.com/watch?v=RuNolAh_4bU)

[![](https://img.youtube.com/vi/RuNolAh_4bU/0.jpg)](https://www.youtube.com/watch?v=RuNolAh_4bU)

* Episode 2 - [Extracting relationships from books and network analyses](https://www.youtube.com/watch?v=fAHkJ_Dhr50)

[![](https://img.youtube.com/vi/fAHkJ_Dhr50/0.jpg)](https://www.youtube.com/watch?v=fAHkJ_Dhr50)

